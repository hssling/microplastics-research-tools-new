__projects__ = "https://github.com/explosion/projects"
__projects_branch__ = "v3"
